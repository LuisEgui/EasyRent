<?php

require_once RAIZ_APP.'/Repository.php';

/**
 * A specific repository for Damages
 */
interface DamageRepository extends Repository {
    //Aqui se declaran las funciones RELACIONADAS CON LA BASE DE DATOS que se implementarán en "MysqlDamageRepository"
    public function findByVehicle($vehicle);
    

}