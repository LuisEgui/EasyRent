<footer>
	
	<a href="sobrenosotros.php">Sobre Nosotros</a>
	<a href="faq.php">FAQ</a>
	<a href="contacto.php">Contacto</a>

</footer>
