<?php
echo '<h2>Vehiculo añadido</h2>';
echo '<p>Volviendo al indice... Espere unos segundos...</p>';
echo '<meta http-equiv="refresh" content="3;url=index.php">';